<?php

    return [
        'title_page' => 'Nhập khẩu',

        'form' => [

        ],

        'alert' => [

        ]
    ];

?>