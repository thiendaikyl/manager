# Manager
# Author **IzeroCs**

# Sửa lỗi cache php trên trình duyệt
# Thêm chức năng thêm input file upload bằng javascript


# Chức năng thêm:
# Thêm sửa tập tin theo dòng được chọn
# Thêm phần cài đặt đăng nhập sau một thời gian không sử dụng sẽ chết session
# Thêm tìm kiếm file và chức năng
# Thêm xác thực bằng mã gửi qua email
# Thêm cảnh báo nếu dùng tài khoản mặc định