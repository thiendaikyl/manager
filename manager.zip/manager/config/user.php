<?php

    if (defined('LOADED') == false)
        exit;

    return [
        [
            'username' => 'Admin',
            'password' => Librarys\App\AppUser::passwordEncode('12345'),
            'position' => 8,

            'time_create' => 0,
            'time_modify' => 0,
            'time_login'  => 0
        ],

        [
            'username' => 'IzeroCs',
            'password' => Librarys\App\AppUser::passwordEncode('12345'),
            'position' => 8,

            'time_create' => 0,
            'time_modify' => 0,
            'time_login'  => 0
        ],

        [
            'username' => 'User',
            'password' => Librarys\App\AppUser::passwordEncode('12345'),
            'position' => 1,

            'time_create' => 0,
            'time_modify' => 0,
            'time_login'  => 0
        ],

        [
            'username' => 'Band',
            'password' => Librarys\App\AppUser::passwordEncode('12345'),
            'position' => 0,

            'time_create' => 0,
            'time_modify' => 0,
            'time_login'  => 0
        ]
    ];

?>