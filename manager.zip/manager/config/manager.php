<?php

    return [
        'login' => [
            'enable_forgot_password' => true
        ],

        'paging' => [
            'file_home_list' => 10
        ]
    ];

?>