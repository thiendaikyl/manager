<?php

    define('ALERT_LOGIN', 'alert_login');
    define('ALERT_INDEX', 'alert_index');

    define('ALERT_CREATE', 'alert_create');
    define('ALERT_UPLOAD', 'alert_upload');
    define('ALERT_IMPORT', 'alert_import');

?>